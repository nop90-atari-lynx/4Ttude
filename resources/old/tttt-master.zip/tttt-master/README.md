# 4x4x4 Tic-Tac-Toe

This project contains a simple C program that will play 4x4x4 Tic-Tac-Toe
using only the stdio library.

It is designed so that it should be possible to build and run this program
on an embedded machine, and in particular the ZipCPU, just to have some fun
and to demonstrate the capabilities of both the ZipCPU, as well as the
newlib toolchain.
